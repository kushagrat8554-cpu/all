import streamlit as st
import pandas as pd
import numpy as np
import joblib
from tensorflow.keras.models import load_model # type: ignore
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt
import time

st.set_page_config(page_title="🛠️ DIGITAL TWIN FOR CONDITION MONITORING 🪛", layout="wide")

# ---------------------------
# Load models
# ---------------------------
rf_model = joblib.load("C:/Users/T8554/Desktop/DigitalTwinProject/notebook/rf_rul_fd001.pkl")       # Random Forest
lstm_model = load_model("C:/Users/T8554/Desktop/DigitalTwinProject/notebook/lstm_rul_fd001.keras")  # LSTM
autoencoder = load_model("C:/Users/T8554/Desktop/DigitalTwinProject/notebook/autoencoder_xjtu.keras")
scaler = joblib.load("C:/Users/T8554/Desktop/DigitalTwinProject/notebook/scaler_fd001.pkl")

# ---------------------------
# App layout
# ---------------------------
st.title("🛠️ DIGITAL TWIN FOR CONDITION MONITORING 🪛")

option = st.selectbox(
    "Choose dataset",
    ("C-MAPSS FD001 (Engines)", "XJTU-SY Bearings")
)

uploaded_file = st.file_uploader("Upload CSV file for prediction", type="csv")


def get_health_status(value, model_type = "rul"):
    if model_type == "rul":
        if value > 120:
            return "Healthy", "🟢"
        elif value > 80:
            return "Degrading", "🟡"
        elif value > 30:
            return "Critical", "🟠"
        else:
            return "Failure Imminent", "🔴"
    elif model_type == "mse":
        if value < 20:
            return "Healthy", "🟢"
        elif value < 40:
            return "Degrading", "🟡"
        elif value < 90:
            return "Critical", "🟠"
        else:
            return "Failure Imminent", "🔴"

speed = st.slider("⏲ Simulation Speed (seconds per batch) ⌚", 0.1, 2.0, 1.0, 0.1)

if "running" not in st.session_state:
    st.session_state.running = False

if st.button("▶ Run Simulation ▶️"):
    st.session_state.running = True
if st.button("⏸ Pause Simulation ⏸️"):
    st.session_state.running = False

if uploaded_file is not None:
    df = pd.read_csv(uploaded_file)
    st.write("📄 Uploaded Data Preview:", df.head())

    df.rename(columns = {f"sensor_{i}": f"s{i}" for i in range(1, 22)}, inplace=True)

    # Example: Extract sensor columns
    sensor_cols = [f"s{i}" for i in range(1, 22) if f"s{i}" in df.columns]

    if "rul_history" not in st.session_state:
        st.session_state.rul_history = []
    if "mse_history" not in st.session_state:
        st.session_state.mse_history = []


    if option == "C-MAPSS FD001 (Engines)":
        st.subheader("𖣘 RUL Prediction - Engine Monitoring ✈︎")

        # Normalize sensors
        X_scaled = scaler.transform(df[sensor_cols])

        # Simulate batch streaming
        col1, col2 = st.columns([2, 1])
        with col1:
            chart_rul = st.line_chart()
            chart_health = st.line_chart()
        with col2:
            condition_display = st.empty()
            latest_rul_display = st.empty()
            health_comment_display = st.empty()
       
        st.session_state.rul_history = []
       
        for i in range(0, len(df), 10):
            if not st.session_state.running:
                break

           
            batch = X_scaled[i:i+10]
            # Predict using Random Forest model (or replace with lstm_model if you want)
            rul_pred = rf_model.predict(batch)
            latest_rul = rul_pred[-1]
            health_status, color = get_health_status(latest_rul, model_type="rul")
            st.session_state.rul_history.append(latest_rul)

            # Update chart and condition
            chart_rul.add_rows(pd.DataFrame(rul_pred, columns=["RUL"]))
            chart_health.add_rows(pd.DataFrame([len(st.session_state.rul_history), latest_rul], index=["step", "RUL"]).T)
            condition_display.markdown(f"### Current Condition: {color} **{health_status}**")
            latest_rul_display.metric("Predicted RUL",f"**{latest_rul:.2f}** cycles")
            # condition_display.metric("Current Condition", health_status, delta = None)
            if latest_rul <= 30:
                health_comment_display.error("⚠️ Machine is near FAILURE! Immediate maintenance required.")
            elif latest_rul <= 80:
                health_comment_display.warning("⚠️ Machine is Degrading. Schedule maintenance soon.")
            else:
                health_comment_display.info("✅ Machine remains in Healthy Condition.")

            time.sleep(speed)

        if st.session_state.rul_history:
            final_rul = st.session_state.rul_history[-1]
            st.success(f"🛎️ Simulation Completed. Final Predicted RUL: {final_rul:.2f} cycles")

            # ---- Export Final Report ----
            report_df = pd.DataFrame({
                "Step": list(range(1, len(st.session_state.rul_history)+1)),
                "Predicted_RUL": st.session_state.rul_history
            })

            csv = report_df.to_csv(index=False).encode("utf-8")

            st.download_button("📥 Download Report (CSV)", csv, "fd001_rul_report.csv", "text/csv")

            if final_rul <= 30:
                st.error("⚠️ Machine is near FAILURE! Immediate maintenance required.")
            elif final_rul <= 80:
                st.warning("⚠️ Machine is Degrading. Schedule maintenance soon.")
            else:
                st.info("✅ Machine remains in Healthy Condition.")

    elif option == "XJTU-SY Bearings":
        st.subheader("⚙ Anomaly Detection - Bearing Monitoring")

        X = df.values
        col1, col2 = st.columns([2, 1])
        with col1:
            chart_mse = st.line_chart()
            chart_health = st.line_chart()
        with col2:
            condition_display = st.empty()
            latest_mse_display = st.empty()
            health_comment_display = st.empty()
       
        st.session_state.mse_history = []

        for i in range(0, len(X), 10):
            if not st.session_state.running:
                break

            batch = X[i:i+10]
            recon = autoencoder.predict(batch)
            mse = np.mean((batch - recon) ** 2, axis=1)
            latest_mse = mse[-1]
            st.session_state.mse_history.append(latest_mse)

            health_status, color = get_health_status(latest_mse, model_type="mse")


            # Update chart and condition
            chart_mse.add_rows(pd.DataFrame(mse, columns=["Reconstruction Error"]))
            chart_health.add_rows(pd.DataFrame([len(st.session_state.mse_history), latest_mse], index=["step", "mse"]).T)
            condition_display.markdown(f"### Current Condition: {color} **{health_status}**")
            latest_mse_display.metric("Reconstruction Error (MSE)",f"**{latest_mse:.4f}**")

            if latest_mse >= 110:
                health_comment_display.error("⚠️ Bearing is FAILED or near FAILURE! Immediate maintenance required.")
            elif latest_mse >= 60:
                health_comment_display.warning("⚠️ Bearing condition is CRITICAL. Schedule maintenance soon.")
            elif latest_mse >= 20:
                health_comment_display.warning("⚠️ Bearing is Deteriorating. Monitor closely.")
            else:
                health_comment_display.info("✅ Bearing remains in Healthy Condition.")

            time.sleep(speed)
       
        if st.session_state.mse_history:
            final_mse = st.session_state.mse_history[-1]
            st.success(f"🛎️ Simulation Completed. Final Reconstruction Error (MSE): {final_mse:.4f}")

            # ---- Export Final Report ----
            report_df = pd.DataFrame({
                "Step": list(range(1, len(st.session_state.mse_history)+1)),
                "Reconstruction_Error_MSE": st.session_state.mse_history
            })

            csv = report_df.to_csv(index=False).encode("utf-8")
            st.download_button("📥 Download Report (CSV)", csv, "xjtu_mse_bearing_report.csv", "text/csv")

            if final_mse >= 110:
                st.error("⚠️ Bearing is FAILED or near FAILURE! Immediate maintenance required.")
            elif final_mse >= 60:
                st.warning("⚠️ Bearing condition is CRITICAL. Schedule maintenance soon.")
            elif final_mse >= 20:
                st.warning("⚠️ Bearing is Deteriorating. Monitor closely.")
            else:
                st.info("✅ Bearing remains in Healthy Condition.")
    # ---------------------------
    # Summary Report Section
    # ---------------------------
    st.markdown("---")
    st.subheader("📊 Project Summary Report")

    if st.button("📈 Show Summary Report"):
        # You can customize these based on your evaluation results
        summary_data = {
            "Model": ["Random Forest (FD001)", "LSTM (FD001)", "Random Forest (XJTU)", "Autoencoder (XJTU)"],
            "RMSE": [31.970000, 29.776500, 6.607480, 0.045458],
            "MAE": [26.474700, 18.711000, 4.332090, 0.002066],
            "R²": [0.939730, 0.783756, 0.947351, None]
        }

        df_summary = pd.DataFrame(summary_data)
        st.table(df_summary)

        # Dataset summary
        st.markdown("### 📘 Dataset Overview")
        st.markdown("""
        **C-MAPSS FD001 (Turbofan Engines)**  
        - 100 engines × ~20,000 cycles total  
        - 21 sensor features  
        - Target: Remaining Useful Life (RUL)
        
        **XJTU-SY Bearings Dataset**  
        - 3 bearings × vibration data across multiple runs  
        - Aggregated to 5 key statistical features (RMS, mean, std, max, min)  
        - Target: Health degradation / failure stage
        """)

        # Findings summary
        st.markdown("### 🧠 Findings Summary")
        st.markdown("""
        - **Best Model:** RF (FD001) → Lowest RMSE = 31.97  
        - **LSTM (FD001):** Slightly better MAE but higher RMSE, more complex  
        - **RF (XJTU):** Strong performance on bearing data, RMSE = 6.61
        - **Autoencoder (XJTU):** Best for unsupervised anomaly detection  
        - **Transfer Learning (CNN + CORAL):** Accuracy low due to dissimilar domains, proposed for future work  
        """)

        # Optional download
        csv_summary = df_summary.to_csv(index=False).encode("utf-8")
        st.download_button("📥 Download Summary CSV", csv_summary, "model_summary.csv", "text/csv")